//
//  NotifAlerts+CoreDataClass.swift
//  SuperDeker
//
//  Created by Luis Bermudez on 1/12/21.
//
//

import Foundation
import CoreData

@objc(NotifAlerts)
public class NotifAlerts: NSManagedObject {

}
