//
//  blockList.swift
//  SuperDeker
//
//  Created by Luis Bermudez on 10/25/20.
//

import Foundation

struct blockword : Codable {
    let id: String
    let value: String
}

var blockedWords: [blockword] = [blockword]()

struct blockList {

   static var words = ["anal",
                       "analannie",
                       "analsex",
                       "anus",
                       "arsehole",
                       "ass",
                       "assbagger",
                       "assblaster",
                       "assclown",
                       "asscowboy",
                       "asses",
                       "assfuck",
                       "assfucker",
                       "asshat",
                       "asshole",
                       "assholes",
                       "asshore",
                       "assjockey",
                       "asskiss",
                       "asskisser",
                       "assklown",
                       "asslick",
                       "asslicker",
                       "asslover",
                       "assman",
                       "assmonkey",
                       "assmunch",
                       "assmuncher",
                       "asspacker",
                       "asspirate",
                       "asspuppies",
                       "assranger",
                       "asswhore",
                       "asswipe"
                        ]  // Yea, this is not a constant, but that's alright...
 }



