<?php
$serverName = "s07.everleap.com"; 
$uid = "DB_4666_tuapoyo_user";   
$pwd = "v5592454";  
$databaseName = "DB_4666_tuapoyo";
?>