<?php

$langtext["Recordatorio"]="Reminder";
$langtext["FechaRecordatorio"]="ReminderDate";
$langtext["ObsRecordatorio"]="ReminderComment";
$langtext["Tarea"]="Task";
$langtext["FechaTarea"]="TaskDate";
$langtext["EjecutorTarea"]="TaskExecutor";
$langtext["DescTarea"]="TaskDesc";
$langtext["Cita"]="Appointment";
$langtext["FechaCita"]="AppDate";
$langtext["FechaVencimiento"]="DueDate";
$langtext["FechaAviso"]="AgreedDate";
$langtext["FechaCumple"]="DeadLine";
$langtext["FechaCompromiso"]="CommitmentDate";

?>