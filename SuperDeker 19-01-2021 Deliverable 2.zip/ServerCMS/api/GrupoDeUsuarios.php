<?php
$GruposDeUsuarios=array("superd");

//$GruposDeUsuarios=array("vacunas","ivopasu","claudia","anabell","carolina");

//$GruposDeUsuarios=array("azotea","isabel","anikur","odryazo");

?>